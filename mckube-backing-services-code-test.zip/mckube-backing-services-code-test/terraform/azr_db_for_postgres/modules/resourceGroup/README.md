Terraform module to create a resource group.

Variables:
solution - the name of the solution. Used in tags
environment - the name of the environment. Used in tags

resource_group_name - the name of the resource group name to be deployed
location - where to deploy the resource group
tags - additional tags, as map